The key of an object (or file) is usually the name of the file unless you specifically added the key. In line 48, I have used a String value to "Redirecting.txt" as the key for the file Redirecting.txt. This is called on line 85 in the GetObjectRequest(bucketName, key) method

The key is the unique identification of the file you are downloading or reading.

I have had to hardcode my id and secret key into the app. its ok, its just a user. has same access that I gave to you.

You may need to install maven to get it to work. This is just the netbeans project. Eclipse wouln't work.

I have included the redirecting.txt file to show you what i was working with. Screenshot of results after running the program. Running the program again does not add anymore lines to the database as primary keys have already been used.

Any questions, message me.

